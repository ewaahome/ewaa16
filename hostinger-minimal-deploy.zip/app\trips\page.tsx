/**
 * @deprecated This file is maintained for backward compatibility. 
 * Please use the modular version at app/modules/trips/page.tsx instead.
 */

import TripsPage from "../modules/trips/page";

export default TripsPage;
