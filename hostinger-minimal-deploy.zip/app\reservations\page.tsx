/**
 * @deprecated This file is maintained for backward compatibility. 
 * Please use the modular version at app/modules/reservations/page.tsx instead.
 */

import ReservationsPage from "../modules/reservations/page";

export default ReservationsPage;
