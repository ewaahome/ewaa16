/**
 * @deprecated This file is maintained for backward compatibility. 
 * Please use the modular version at app/modules/properties/page.tsx instead.
 */

import PropertiesPage from "../modules/properties/page";

export default PropertiesPage;
