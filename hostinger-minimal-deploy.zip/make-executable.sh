#!/bin/bash

# Make server startup script executable
chmod +x start-server.sh
echo "✅ Made start-server.sh executable"

# Run the startup script
echo "🚀 Running startup script..."
./start-server.sh 