# Eiwaa Home - Deployment Package

This is a minimal deployment package for the Eiwaa Home application, optimized for Hostinger VPS deployment.

## Project Overview
This is a Next.js application for property rental listings with user authentication, property search, booking, and management features.

## Deployment Steps for Hostinger VPS

### 1. Server Setup
1. Login to your Hostinger VPS via SSH
2. Update system packages:
   ```
   sudo apt update && sudo apt upgrade -y
   ```
3. Install Node.js 18.x:
   ```
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```
4. Install PM2 for process management:
   ```
   sudo npm install -g pm2
   ```
5. Install Nginx:
   ```
   sudo apt install nginx -y
   ```

### 2. Application Deployment
1. Create a directory for your application:
   ```
   mkdir -p /var/www/ewaahome
   ```
2. Upload all files from this package to the directory
3. Navigate to the application directory:
   ```
   cd /var/www/ewaahome
   ```
4. Create a `.env` file from the `.env.example` template:
   ```
   cp .env.example .env
   nano .env  # Edit with your actual values
   ```
5. Install dependencies:
   ```
   npm install
   ```
6. Build the application:
   ```
   npm run build
   ```
7. Start the application with PM2:
   ```
   pm2 start npm --name "ewaahome" -- start
   ```
8. Set PM2 to start on system boot:
   ```
   pm2 startup
   pm2 save
   ```

### 3. Nginx Configuration
1. Create an Nginx configuration file:
   ```
   sudo nano /etc/nginx/sites-available/ewaahome
   ```

2. Add the following configuration:
   ```nginx
   server {
       listen 80;
       server_name your-domain.com www.your-domain.com;

       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

3. Create a symbolic link to enable the site:
   ```
   sudo ln -s /etc/nginx/sites-available/ewaahome /etc/nginx/sites-enabled/
   ```

4. Test the configuration:
   ```
   sudo nginx -t
   ```

5. Restart Nginx:
   ```
   sudo systemctl restart nginx
   ```

### 4. SSL Setup
1. Install Certbot:
   ```
   sudo apt install certbot python3-certbot-nginx -y
   ```

2. Obtain and install an SSL certificate:
   ```
   sudo certbot --nginx -d your-domain.com -d www.your-domain.com
   ```

3. Test automatic renewal:
   ```
   sudo certbot renew --dry-run
   ```

## Environment Variables

Make sure to set all the environment variables listed in .env.example:

- `DATABASE_URL`: Your MongoDB connection string
- `NEXTAUTH_SECRET`: A secure random string for session encryption
- `NEXTAUTH_URL`: Your website URL (e.g., https://your-domain.com)
- Cloudinary credentials for image uploads
- MapBox credentials for location services
- (Optional) OAuth credentials for social login

## Database Setup

The application requires a MongoDB connection:
1. Create a MongoDB Atlas account or use any MongoDB provider
2. Create a new database and user
3. Update the `DATABASE_URL` in your `.env` file with the connection string

## Monitoring and Maintenance

- View PM2 process status: `pm2 status`
- View application logs: `pm2 logs ewaahome`
- Restart application: `pm2 restart ewaahome`
- Update Node.js dependencies periodically: `npm update`

## Troubleshooting

- Check Nginx logs: `sudo tail -f /var/log/nginx/error.log`
- Check application logs: `pm2 logs ewaahome`
- Ensure all environment variables are set correctly
- Verify MongoDB connection is working
- Check that port 3000 is not blocked by firewall

## Important Notes

- The application requires Node.js 18.x or later
- For high-traffic sites, consider using a more robust MongoDB setup
- Regular backups of your MongoDB database are recommended
- Update all npm packages regularly for security patches
