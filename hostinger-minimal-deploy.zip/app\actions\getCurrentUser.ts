/**
 * @deprecated This file is maintained for backward compatibility. 
 * Please use the modular version at app/modules/auth/actions/getCurrentUser.ts instead.
 */

import getCurrentUser from "@/app/modules/auth/actions/getCurrentUser";

export default getCurrentUser;

