/**
 * @deprecated This file is maintained for backward compatibility. 
 * Please use the modular version at app/modules/favorites/page.tsx instead.
 */

import FavoritesPage from "../modules/favorites/page";

export default FavoritesPage;
